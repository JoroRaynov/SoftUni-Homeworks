import { get, post, put, del } from '../api/api.js'

export async function getAllPosts() {
    return await get('/data/posts?sortBy=_createdOn%20desc');
}


export async function getById(id) {
    return await get('/data/posts/' + id);
}

// export async function getAllDonations() {
//     return await get('/data/donations')
// }

export async function createPost(data) {
    return await post('/data/posts', data)
}

export async function updatePost(id, data) {
    return await put('/data/posts/' + id, data)
}

export async function deletePost(id) {
    return del('/data/posts/' + id)
}

export async function getAllUserPosts(userId) {
    return await get(`/data/posts?where=_ownerId%3D%22${userId}%22&sortBy=_createdOn%20desc`)
}